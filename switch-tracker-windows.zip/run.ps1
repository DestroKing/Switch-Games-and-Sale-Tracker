# Starts the app. Called by START.bat; you should not need to run it yourself.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
    $env:PATH = "$env:USERPROFILE\.local\bin;$env:PATH"
}

# Until the dashboard lands, this runs the self-check so START.bat always does
# something useful and verifiable. Swap to "serve" when the dashboard is built.
$command = if ($args.Count -gt 0) { $args } else { @("spike") }

uv run python -m switch_tracker @command
exit $LASTEXITCODE
