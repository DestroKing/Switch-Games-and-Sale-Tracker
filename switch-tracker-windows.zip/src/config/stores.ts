import type { StoreConfig } from "../core/types.ts";

/**
 * `kind` for the API-based (SHOPIFY/WOOCOMMERCE) stores below is a
 * hypothesis — run `bun run probe` and correct this file, or let it write
 * stores.local.json, from what it reports. BROWSER-kind stores need a
 * `PROFILES` entry in src/adapters/browser.ts and don't go through probe at
 * all (see probe.ts's early skip for BROWSER/MANUAL kind).
 */
export const STORES: readonly StoreConfig[] = [
  // ---- Tier 2: dedicated retailers. The real catalogue lives here. ----
  {
    id: "nistore",
    name: "NI Gaming Store",
    baseUrl: "https://nistore.in",
    kind: "WOOCOMMERCE",
    currency: "INR",
    tier: 2,
    enabled: true,
    platformHint: "SWITCH",
    collections: ["nintendo-switch-games", "nintendo-switch-pre-owned-games", "nintendo-switch-2"],
    note: "Verified: three pages of Switch/Switch 2 cartridges. Also carries consoles/accessories/collectibles (Bayblade, Dock Cover, Card Holders) — scoped to its actual games categories rather than relying on classification alone.",
  },
  {
    id: "gameloot", name: "GameLoot", baseUrl: "https://gameloot.in", kind: "SHOPIFY",
    currency: "INR", tier: 2, enabled: true, platformHint: "SWITCH",
    collections: ["nintendo-switch"],
    note: "General electronics/gift-card/subscription retailer — scoped to its Nintendo Switch category (accessories/consoles have their own separate categories that this deliberately excludes).",
  },
  {
    id: "nekavo", name: "NEKAVO", baseUrl: "https://nekavo.com", kind: "WOOCOMMERCE",
    currency: "INR", tier: 2, enabled: true, platformHint: "SWITCH",
    collections: ["nintendo-switch-games", "nintendo-switch-2"],
    note: "Primarily a Funko Pop/anime collectibles store — scoped to its two Switch games categories, excludes nintendo-accessories and nintendo-merchandise.",
  },

  // Unverified as cartridge sellers — cheap to keep, cheap to delete.
  {
    id: "emartgames", name: "Emart Games", baseUrl: "https://emartgames.in", kind: "SHOPIFY",
    currency: "INR", tier: 2, enabled: true, platformHint: "SWITCH",
    collections: ["nintendo-switch-games-cds-online-india", "nintendo-switch-2-games"],
    note: "Multi-console store (also sells PS3/PS4/PS5) — scoped to its two Switch categories, found via `bun run probe`'s category listing.",
  },
  {
    id: "hgworld", name: "HG World", baseUrl: "https://hgworld.in", kind: "SHOPIFY",
    currency: "INR", tier: 2, enabled: true, platformHint: "SWITCH",
    collections: ["nintendo-games"],
    note: "Confirmed games category (https://hgworld.in/product-category/gaming-tittle/nintendo-games/) — probe's category listing missed it at first because the store has 100+ categories and the fetch wasn't paginated.",
  },
  {
    id: "zozila", name: "Zozila", baseUrl: "https://zozila.com", kind: "SHOPIFY",
    currency: "INR", tier: 2, enabled: false, platformHint: "SWITCH",
    note: "Disabled: `bun run probe`'s category listing shows it's a digital gift-card/voucher marketplace (Amazon, Apple iTunes, Air India, Apollo Pharmacy...), not a cartridge retailer — none of its ~100 categories matched Switch/Nintendo.",
  },
  {
    id: "designinfo", name: "DesignInfo", baseUrl: "https://www.designinfo.in", kind: "SHOPIFY",
    currency: "INR", tier: 2, enabled: true,
    // Not a games-only category (it's named for consoles, and probably
    // mixes in accessories too) but still scoped to it — this is a 570+
    // category camera/audio/electronics store, so even an imprecise
    // Nintendo-only category cuts the fetch down enormously and gives
    // classify() a far safer job: separating games from consoles/
    // accessories within an already-Nintendo-scoped set, not fishing them
    // out of the entire unrelated catalogue.
    collections: ["nintendo-gaming-consoles"],
    // No platformHint on purpose: even within this category, it's still not
    // guaranteed everything is Switch (could be other Nintendo hardware) —
    // requiring an explicit "Switch" mention is the safe default, the same
    // reasoning that applies to the rest of this unscoped, multi-brand site.
    note: "Real kind is WooCommerce, not Shopify — confirmed via probe, corrects itself into stores.local.json. Scoped to its one Nintendo-related category; no separate games-only split exists on this site.",
  },

  // ---- Tier 1: browser automation, run last. ----
  {
    id: "amazon_in",
    name: "Amazon.in",
    baseUrl: "https://www.amazon.in",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    // A real browse-node category listing, not a keyword search — covers
    // both Switch and Switch 2 in one URL (confirmed ~47 pages), more
    // precise and more complete than the old "k=nintendo+switch+games"
    // free-text search.
    searchUrls: [
      "https://www.amazon.in/s?i=videogames&rh=n%3A976460031%2Cn%3A13995115031%2Cn%3A13995151031&dc&ds=v1%3AiZuYA9QV0eVzZbIDkLndPnQhVZrwc%2BriiE0a8ssyvMY&qid=1787339967&rnid=13995115031&ref=sr_nr_n_1&page={p}",
    ],
    note: "Real bot detection. Cards keyed on data-component-type, which is stabler than Amazon's class names.",
  },
  {
    id: "flipkart",
    name: "Flipkart",
    baseUrl: "https://www.flipkart.com",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    // A real category page with platform facets applied (Switch + Switch 2
    // both, in one URL, confirmed ~7 pages) instead of a free-text search.
    searchUrls: [
      "https://www.flipkart.com/gaming/games/physical-game/pr?sid=4rr%2Cfa6%2C32v&marketplace=FLIPKART&p%5B%5D=facets.platform%255B%255D%3DSwitch&p%5B%5D=facets.platform%255B%255D%3DSwitch%2B2&page={p}",
    ],
    note: "Obfuscated, rotating class names. Adapter prefers __INITIAL_STATE__ over CSS for this reason.",
  },
  {
    id: "gamestheshop",
    name: "Games The Shop",
    baseUrl: "https://www.gamestheshop.com",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    searchUrls: [
      "https://www.gamestheshop.com/search?condition=Physical&platforms=Nintendo+Switch&categories=Game+Software&page={p}",
      "https://www.gamestheshop.com/search?condition=Physical&platforms=Nintendo+Switch+2&categories=Game+Software&page={p}",
    ],
    note: "Custom Next.js storefront, not Shopify/WooCommerce — has no public product API, so it's scraped like Amazon/Flipkart. The &page={p} suffix is a guess; confirm/adjust once inspect.ts shows page 2's real URL shape.",
  },
  {
    id: "gamenation",
    name: "GameNation",
    baseUrl: "https://gamenation.in",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    searchUrls: ["https://gamenation.in/PlayStation/?platform=nintendoSwitch%2CnintendoSwitch2&page={p}"],
    note: "Custom storefront (the /PlayStation/ path is misleading — it's their general catalogue, filtered by the platform query param to both Switch and Switch 2). &page={p} is a guess to confirm via inspect.ts.",
  },
  {
    id: "mcubegames",
    name: "Mcube Games",
    baseUrl: "https://www.mcubegames.in",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    searchUrls: ["https://www.mcubegames.in/shop?platforms=60&platforms=93&page={p}"],
    note: "Custom storefront filtered by numeric platform IDs (60/93 = Switch/Switch 2 per the URL given). &page={p} is a guess to confirm via inspect.ts.",
  },
  {
    id: "e2zstore",
    name: "e2zSTORE",
    baseUrl: "https://e2zstore.com",
    kind: "BROWSER",
    currency: "INR",
    tier: 1,
    enabled: true,
    platformHint: "SWITCH",
    searchUrls: ["https://e2zstore.com/category/nintendo-games/?paged={p}"],
    note: "Every direct HTTP request (Store API and plain homepage fetch) failed here even though the site loads fine in a real browser — almost certainly bot protection blocking non-browser traffic, so it needs Playwright rather than the WooCommerce adapter. baseUrl switched from www to non-www to match the URL that's confirmed to load.",
  },
  // ---- Parked ----
  {
    id: "playasia",
    name: "Play-Asia",
    baseUrl: "https://www.play-asia.com",
    kind: "BROWSER",
    currency: "USD",
    tier: 1,
    enabled: false,
    searchUrls: ["https://www.play-asia.com/search/nintendo+switch?page={p}"],
    note: "Parked by request. Currency is USD — the INR shown on-site is a display conversion, not a price. Re-enable by flipping this flag.",
  },
];
