"""Argv dispatch -- the exe's five personalities (LLD section 3.4).

The UI process ('serve') must never import Playwright or any adapter, so those
imports live INSIDE their subcommand branches, never at module top level.
tests/test_import_boundary.py asserts this in a subprocess.
"""

from __future__ import annotations

import multiprocessing
import sys


def main() -> int:
    # Must precede any import that could spawn a process, or a frozen build
    # re-executes itself recursively on Windows.
    multiprocessing.freeze_support()

    command = sys.argv[1] if len(sys.argv) > 1 else "serve"

    if command == "spike":
        from switch_tracker.spike import run

        return run()

    print("usage: switch-tracker <serve|collect|probe|fx|inspect|spike>", file=sys.stderr)
    print(f"unknown command: {command!r}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
